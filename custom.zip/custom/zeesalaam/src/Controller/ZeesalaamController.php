<?php
/**
 * @file
 * @author Waliullah Khan
 * Contains \Drupal\zeesalaam\Controller\ZeesalaamController.
 * Please place this file under your zeesalaam(module_root_folder)/src/Controller/
 */
namespace Drupal\zeesalaam\Controller;
/**
 * Provides route responses for the Example module.
 */
class ZeesalaamController {
  /**
   * Returns a simple page.
   *
   * @return array
   *   A simple renderable array.
   */
  public function autopublishedNews() {
	$database = \Drupal::database();

    $query = $database->select('node_field_data', 'n');
	
	$query->join('node__field_publish_later','e','e.entity_id = n.nid');
	$query->join('node__field_publish_at','p','p.entity_id = n.nid');
	$query->fields('n', ['nid','title']);
	$query->fields('p', ['field_publish_at_value']);
	$query->condition('n.status',0);
	$query->condition('p.field_publish_at_value', time(), '<');
	$query->condition('e.field_publish_later_value',0);
	$query->orderBy('p.field_publish_at_value', 'asc');
	$query->range(0,49);
    $emb_nodes = $query->execute();
	$row1 = '';
    while($record = $emb_nodes->fetchAssoc()){
		
		$nid[$record['nid']] = $record['title'];
		$row1.= '<tr><td>'.$record['nid'].'</td><td>'.$record['title'].'</td></tr>';
		# Publish and save node
		$node = \Drupal\node\Entity\Node::load($record['nid']);
		$node->set("created", $record['field_publish_at_value']);
        $node->set("changed", $record['field_publish_at_value']);
        $node->setPublished(TRUE);
		$node->save();
		
	}
   
   $header = '<tr><th>NID</th><th>TITLE</th></tr>';
	$rows = '<p>' . t('Auto Published') . '</p>'.'<table>'.$header.$row1.'</table>';
	
	$my_dynamic_html = '<ul>'.$rows.'</ul>';
	$render_array = array(
		'#markup' => $my_dynamic_html,
		'#prefix' => '<div>',
		'#suffix' => '</div>',
	);
	
	//echo "<pre>";
	//print_r(@$nid);
    return $render_array;
	
  }
  public function autoPublishedFromTranscode() {
	  
	  echo "hello";
	  die;
  }
}
?>