(function ($, Drupal) {
 /*------------------------------------ Getting Video Data From YouTube/Transcode API ------------------------------------*/
	Drupal.behaviors.zeesalaamAdmin = {
		attach: function (context, settings) {
			$('#edit-field-yt-code-wrapper').once().append('<input type="button" id="getvideo_data" name="get_video_data" value="Get Video" class="button"><div class="clearfix"></div><div id="video_preview"></div><div class="clearfix"></div><div id="videothumbnailspreview"></div><div class="clearfix"></div><div id="divSelectVideoImage"></div><div class="clearfix"></div>');
		   
			$("input[name='field_isyoutube']").once().change(function(){
                if(this.value==1){
                    jwplayer('video_preview').remove();
                    $('#edit-field-yt-code-0-value').val('');
                    $('#edit-field-video-featured-image-url-0-value').val('');
                    $('#edit-field-video-duration-0-value').val('');
                    $('#videothumbnailspreview').html('');
                    $('#divSelectVideoImage').html('');
                }else{
                    $('#edit-field-yt-code-0-value').val('');
                    $('#edit-field-video-featured-image-url-0-value').val('');
                    $('#edit-field-video-duration-0-value').val('');
                    $('#video_preview').html('');
                    $('#videothumbnailspreview').html('');
                    $('#divSelectVideoImage').html('');
                }
                
            });
			$("input[name='field_publish_later']").once().change(function(){
               
               if(this.value == 0) {
				  $("input[name='status[value]']").attr('checked', false); 
			   } else {
				  $("input[name='status[value]']").attr('checked', true); 
			   }
            });
			 /* function for get video data on click   */
			$("#getvideo_data").once().on('click', function () {
				var videourldata = $.trim($('#edit-field-yt-code-0-value').val());
				if(videourldata == '') {
					$('#video_preview').html('Please Enter YT Code');
					$('#edit-field-yt-code-0-value').css('border-color', 'red');
				} else {
					$('#edit-field-yt-code-0-value').css('border-color', '');
					var video_type = $("input[name='field_isyoutube']:checked").val();
					
					if(video_type == 1){
						//YouTube Video bImTB8omR0Y
						var v_iframe_id = $.trim($('#edit-field-yt-code-0-value').val());
						var youtubeApi = "AIzaSyDlOaSOXEHxUfBDtGJL_ljPSGkGPh51OVM";
						$.ajax({
							url: "https://www.googleapis.com/youtube/v3/videos?id=" + v_iframe_id + "&key=" + youtubeApi + "&fields=items(snippet(title,thumbnails,description),contentDetails(duration))&part=snippet,contentDetails",
							dataType: "json",
							async: true,
							success: function (data) {
								console.log(data);
								if(data.items.length != 0 ){
									var v_iframe = "<iframe width='560' height='315' src='https://www.youtube.com/embed/" + v_iframe_id +"' frameborder='0' allow='autoplay; encrypted-media' allowfullscreen></iframe>";
									$( "#video_preview" ).html(v_iframe);
									//getThumbnail();
									$( "#videothumbnailspreview" ).html("<img src="+data.items[0].snippet.thumbnails.high.url+" width='480' height='360'>");
								   $( "#edit-field-video-featured-image-url-0-value" ).val(data.items[0].snippet.thumbnails.high.url);
									getDuration();
								}else{
									$( "#videothumbnailspreview" ).html("");
									$( "#edit-field-video-featured-image-url-0-value" ).val("");
									$('#divSelectVideoImage').html(' <p>Please Enter Valid Youtube Video ID. </p>');
									return false;		

								}
							},
							error: function (err) {
								$( "#videothumbnailspreview" ).html("");
								$( "#edit-field-video-featured-image-url-0-value" ).val("");
								$('#divSelectVideoImage').html(' <p>Please Enter Valid Youtube Video ID. </p>');
								return false;
							}
						});
					
					} else if(video_type == 0) {
						// transcode video : hardik_fast_9day
						var tanscodeAPI = "http://transcoding.zeenews.com/get_info/";
						var transcodeId = $.trim($('#edit-field-yt-code-0-value').val());
						var txtTranscodeAPIURL = tanscodeAPI + transcodeId;
							$.ajax({
							url: txtTranscodeAPIURL,
							type: "GET",
							dataType: "json",
							async: false,
							success: function (result) {
							$('#video_preview').html('');
							$('#videothumbnailspreview').html('');
							$('#divSelectVideoImage').html('');
							if (result.title != null) {
							$("#edit-title-0-value").val(result.title);

							} else {
							$("#edit-title-0-value").val('');
							}
							if (result.description != null) {
							CKEDITOR.instances['edit-body-0-value'].setData(result.description);
							}
							else {
							//CKEDITOR.instances['edit-body-0-value'].setData('');
							}
							BindVideoPreview(result.url_video, result.url_trickplay);
							console.log(result.thumbnails);
					
							BindHtml(result.thumbnails);
							$("input[name='rbVideoImage']").change(function(){
							$( "#edit-field-video-featured-image-url-0-value" ).val(this.value);
							});
							},
							error: function (err) {
							$('#video_preview').html('');
							$('#videothumbnailspreview').html('');
							$('#divSelectVideoImage').html(' <p>Please Enter Valid Transcode Video ID. </p>');
							return false;
							}
							});
					}
				}
				 
				
			});
			function getDuration() {
				var videoid = $.trim($('#edit-field-yt-code-0-value').val());
				var youtubeApi = "AIzaSyDlOaSOXEHxUfBDtGJL_ljPSGkGPh51OVM";
				$.ajax({
				url: "https://www.googleapis.com/youtube/v3/videos?id=" + videoid + "&key=" + youtubeApi + "&part=snippet,contentDetails,statistics,status",
				dataType: "json",
				async: true,
				success: function (data) {
				$("#edit-title-0-value").val(data.items[0].snippet.title);
				//$('input[id$="hddescription"]').val(data.items[0].snippet.description);
				str = data.items[0].contentDetails.duration;
				str = data.items[0].contentDetails.duration.replace("PT", "");
				var hour = "";
				var minute = "";
				var sec = "";
				if (str.indexOf("H") != -1) {
				str = str.replace("H", ":");
				}
				else {
				str = '00:' + str;
				}
				if (str.indexOf("M") != -1) {
				str = str.replace("M", ":");
				}
				else {
				str = str.replace(":", ":00:");
				}

				if (str.indexOf("S") != -1) {
				str = str.replace("S", "");
				}
				else {
				str = str + "00";

				}

				if (str.split(':')[0].length == 1) {

				hour = "0" + str.split(':')[0];
				}

				else {
				hour = str.split(':')[0];

				}


				if (str.split(':')[1].length == 1) {

				minute = "0" + str.split(':')[1];
				}
				else {
				minute = str.split(':')[1];
				}
				if (str.split(':')[2].length == 1) {

				sec = "0" + str.split(':')[2];
				}
				else {

				sec = str.split(':')[2];
				}

				var duration = hour + ":" + minute + ":" + sec;
				var description =  data.items[0].snippet.description
				if (description != null) {
				CKEDITOR.instances['edit-body-0-value'].setData(description);
				}
				else {
				CKEDITOR.instances['edit-body-0-value'].setData('');
				}
				$( "#edit-field-video-duration-0-value" ).val(duration);
				}
				});
			}
			function BindVideoPreview(videourl, trickplayurl) {
                jwplayer("video_preview").setup({
                    primary: "flash",
                    playlist: [{
                        file: videourl,
                        tracks: [{
                            file: trickplayurl,
                            kind: "thumbnails"
                        }]
                    }],
                    width: 550,
                    height: 315
                });
            }
			function BindHtml(result) {
				//alert(result);
				var thumbnailsList = result;
				var html = "<br> <b>Video Thumbnail <span style='color:red'>*</span>:</b><br>";
				var i = 0;
				$(thumbnailsList).each(function () {
					if( i == 0){
						var selected = "checked";
						$( "#edit-field-video-featured-image-url-0-value" ).val(this);		
					}else{
						var selected = "";
					}

					html += "<div class='col-sm-3 popuphead'><input type='radio' name='rbVideoImage' id='thumbid'  value=" + this + "  class='pull-left' " + selected + "><div class='thumbnail'><div class='image view view-first'><div class='category-thumb-icon'><i class='fa fa-camera'></i> </div><img class='img-responsive'  width='480' height='360' alt='' src='" + this + "'></div></div></div></div>";
					i++;
				});
				$('#videothumbnailspreview').html(html);
            }
			

		}
		 
		
	}
})(jQuery, Drupal);	